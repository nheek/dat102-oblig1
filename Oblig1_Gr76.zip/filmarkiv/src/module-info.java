module filmarkiv {
	requires junit;
	requires org.junit.jupiter.api;
}